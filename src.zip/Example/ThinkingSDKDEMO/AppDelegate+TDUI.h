//
//  AppDelegate+TDUI.h
//  ThinkingSDKDEMO
//
//  Created by syj on 2019/6/24.
//  Copyright © 2019年 thinking. All rights reserved.
//

#import "AppDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface AppDelegate (TDUI)

- (UIViewController *)createRootViewController;

@end

NS_ASSUME_NONNULL_END
