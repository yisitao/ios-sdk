//
//  TDMacro.h
//  ThinkingSDKDEMO
//
//  Created by LiHuanan on 2020/7/22.
//  Copyright © 2020 thinking. All rights reserved.
//

#ifndef TDMacro_h
#define TDMacro_h

#define kTDScreenWidth [UIScreen mainScreen].bounds.size.width
#define kTDScreenHeight [UIScreen mainScreen].bounds.size.height

#endif /* TDMacro_h */
