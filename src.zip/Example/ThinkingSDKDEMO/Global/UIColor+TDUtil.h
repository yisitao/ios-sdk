
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIColor (TDUtil)

@property (nonatomic, strong, class, readonly) UIColor *mainColor;
@property (nonatomic, strong, class, readonly) UIColor *tc9;

@end

NS_ASSUME_NONNULL_END
