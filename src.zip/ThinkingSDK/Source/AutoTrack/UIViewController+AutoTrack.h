#import <UIKit/UIKit.h>

@interface UIViewController (AutoTrack)

- (void)td_autotrack_viewWillAppear:(BOOL)animated;

@end
